# [Nombre del producto]

> Documento de partida del proyecto. Lo escribe el PM antes del primer chat y se actualiza cuando cambia algo de lo que dice.
> Va en la raíz de la carpeta vinculada al Proyecto de Claude, no dentro de `docs/`.
> **Última actualización:** [fecha]

## 1. Qué es
[Dos o tres líneas: qué organización o qué personas, y qué situación se quiere mejorar. Sin describir la solución ni dar por hecho que hace falta una aplicación.]

## 2. Quién lo dirige
- **Product Manager:** [nombre]
- **A quién hay que validar las cosas:** [personas o papeles, y cómo se les consulta]

## 3. Material de partida
| Qué hay | Dónde | Límite |
| --- | --- | --- |
| [Entrevistas, notas, datos, comentarios…] | [Carpeta o archivos] | [Cuántas personas, qué periodo] |

[Si no hay material: «Partimos de una idea. No hay evidencia todavía».]

## 4. Restricciones
Valen para todo lo que se haga en el proyecto.
- [Datos que no se pueden pedir, mostrar ni guardar.]
- [Límites legales, de privacidad o de alcance.]
- [Otras condiciones fijadas antes de empezar.]

## 5. Decisiones ya tomadas
Solo las que vienen dadas de fuera. Lo demás se decide por el camino.
- [Por ejemplo: se va a construir una herramienta; formato web pensada para móvil; plazo.]
- [O bien: ninguna.]

## 6. Herramientas
| Para qué | Herramienta | Detalle |
| --- | --- | --- |
| Repositorio | GitHub | [usuario/repositorio] · rama de trabajo [develop] · producción [main] |
| Construcción | Lovable | [workspace] |
| Datos | Supabase propio | [organización] · desarrollo y producción |
| Diseño | Claude Design | |
| Referencias de interfaz | Gummble | [o: ninguna] |
| Publicación | Vercel | [dominio] |
| Medición | [PostHog u otra] | |

[Borra las filas que no apliquen. No escribas aquí claves ni contraseñas.]

## 7. Cómo responder
- **Idioma:** [castellano]
- **Contexto de uso:** [trabajo individual / se proyecta en directo ante una audiencia]
- [Cualquier preferencia de formato.]
