# CADUCA · proyecto de trabajo (v1.2)

Estructura ajustada a la arquitectura documentada en Notion, `Skills del proceso · Product Builder y Product Setup`, consultada el 14/11/2026.

- `material/` — insumos reales de contexto público y materiales sintéticos de investigación para Product Builder.
- `docs/` — carpetas vacías de destino. Los archivos los crean las skills cuando sus entradas y aprobaciones están listas.
- `AGENTS.md` — NO se entrega: debe prepararse en la fase que corresponda, sin fingir que está aprobado o sincronizado.
- GitHub — NO se conecta ni se crea por descomprimir este paquete.
- La segunda entrevista ficticia se reserva fuera de este paquete para una iteración posterior.

**Primer paso**: desde Claude con Product Builder disponible, solicitar `analizar-evidencias` sobre `material/`, con hallazgos respaldados por ID y cita de fila/pregunta, y guardar el borrador en `docs/product/evidence-summary.md`. No anticipar decisiones de MVP.

Los materiales de `material/01_evidencias_sinteticas/` son inventados para el ejercicio y no representan investigación real ni cifras de mercado.
