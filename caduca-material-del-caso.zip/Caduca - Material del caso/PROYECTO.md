# CADUCA · Contexto inicial del proyecto

> Documento de partida del proyecto, redactado por el PM antes del primer chat y actualizado solo cuando cambie una condición de partida.
> Se guarda en la raíz de la carpeta vinculada, no en `docs/`; los documentos de `docs/` los generan las skills.
> **Última actualización:** 2026-11-14.

## 1. Qué es

CADUCA es el caso de trabajo de una **asociación vecinal ficticia** interesada en reducir el desperdicio evitable de alimentos en hogares urbanos. Se quiere comprender por qué algunos alimentos comprados para consumir terminan olvidados, deteriorados o descartados, y qué consecuencias tiene para las personas y sus hábitos. **Todavía no está definido el problema prioritario ni la solución**: ambos deben emerger del análisis de evidencias, la exploración de alternativas y las decisiones del responsable de producto.

## 2. Quién lo dirige y quién valida

- **Responsable de producto y facilitador:** Óscar Subirats. Dirige el proceso, prioriza y aprueba los entregables y decisiones de alcance, diseño y construcción.
- **Validación de negocio y necesidades:** en este taller la asociación y los participantes de la investigación son ficticios. El responsable de producto valida las decisiones del ejercicio; ninguna conclusión se presentará como validada por usuarios reales.
- **Regla de aprobación:** una propuesta de Claude o de una skill no equivale a una decisión aprobada. Ante decisiones relevantes, presentar alternativas y esperar confirmación explícita.

## 3. Material de partida y sus límites

Las fuentes iniciales están en `material/`. Antes de analizarlas, comprobar que los archivos indicados están disponibles.

| Qué hay | Dónde | Límite |
| --- | --- | --- |
| Contexto público, brief e índice de fuentes | `material/00_contexto/` | Los datos generales no demuestran las causas del desperdicio en los hogares del caso ni el impacto de una solución. |
| Cinco entrevistas ficticias (Ana, Bruno, Carla, Diego y Elena) | `material/01_evidencias_sinteticas/01_entrevistas/` | Testimonios creados para el taller; no usuarios reales. |
| Cuestionario, 24 respuestas y metadatos | `material/01_evidencias_sinteticas/02_encuesta/` | Muestra sintética y no representativa. |
| Tres observaciones ficticias de hogares | `material/01_evidencias_sinteticas/03_observaciones/` | Situaciones construidas para practicar análisis; no observaciones empíricas. |
| Diario ficticio de 30 registros de alimentos y metodología | `material/01_evidencias_sinteticas/04_diario/` | Datos sintéticos; no prueban ahorro ni reducción de desperdicio. |
| Artefactos de hábitos actuales y fragmentos de mensajes | `material/01_evidencias_sinteticas/05_artefactos/` | Contexto cualitativo simulado, sujeto a interpretación. |

Usar `material/00_contexto/03_indice_fuentes.csv` para identificar y citar los archivos de origen. **Distinguir datos públicos y materiales simulados**; identificar contradicciones y vacíos sin inventar cifras, atribuciones o certezas. Una segunda entrevista permanece reservada al facilitador y **no forma parte del material inicial**.

## 4. Restricciones

- **Privacidad:** no recoger ni conservar datos reales de salud, menores, direcciones, identificadores personales ni otra información sensible o innecesaria. Utilizar datos ficticios en la demo.
- **Seguridad alimentaria:** distinguir **fecha de caducidad** y **fecha de consumo preferente**; nunca recomendar consumir alimentos después de su fecha de caducidad ni garantizar que un alimento es seguro basándose solo en una fecha introducida.
- **Alcance didáctico:** si se decide construir una aplicación, máximo **cuatro features**, un tipo de usuario, preferiblemente una tabla de datos y una interfaz muy sencilla. Evitar pagos, OCR, escaneo, integraciones y automatizaciones que no sean necesarias para demostrar el proceso.
- **Seguridad técnica:** no publicar secretos ni exponer datos mediante permisos inseguros. Revisar autenticación y RLS antes de cualquier publicación real.

## 5. Decisiones ya tomadas que vienen dadas de fuera

- CADUCA será el **caso del workshop** de Upskill Week del **18 de noviembre de 2026**. El objetivo es enseñar el **método de Product Management asistido por IA**, no construir un producto comercial completo.
- Trabajaremos con **Product Builder** para evidencias, framing, benchmark, MVP, requisitos y diseño, y **Product Setup** para configuración, auditoría y publicación, según sus contratos vigentes.
- Los documentos de producto se **generarán mediante las skills en `docs/`**; no hay un MVP, backlog, modelo de datos ni funcionalidades aprobadas al inicio.
- El trabajo comienza **en local** con este `PROYECTO.md` en la raíz y las fuentes en `material/`. Las decisiones se aprueban por el responsable de producto y se registran; el material no se sube a GitHub antes del paso y la autorización correspondientes.

## 6. Herramientas y entorno

| Para qué | Herramienta | Detalle y estado |
| --- | --- | --- |
| Coordinación y requisitos | Claude · Product Builder | Trabaja con la carpeta local; aplica las skills y las aprobaciones del PM. |
| Configuración y auditoría | Product Setup | Planes específicos con autorización previa a cada cambio; F00 pendiente. |
| Repositorio y ramas | GitHub | Repositorio por crear o vincular; nombre y estrategia de ramas **por confirmar en F00**. No asumir `main`, `develop` o `release`. |
| Diseño | Claude Design | Previsto para los encargos de diseño aprobados; referencias y entregables aún por definir. |
| Construcción | Lovable | Workspace y conexión por verificar. Usar Supabase propio, no Lovable Cloud. |
| Datos | Supabase propio | Proyecto, tablas, migraciones y políticas por definir y aprobar; no precargar un esquema como si fuese el MVP. |
| Publicación | Vercel | Herramienta prevista; dominio o subdominio **pendiente de decisión**. |
| Pruebas | Claude Code / Playwright | Circuito de pruebas previsto; integración definitiva pendiente de validación. |
| Analítica | Sin decisión | No incorporar PostHog ni otras herramientas por defecto; decidir si aportan valor al ejercicio. |

`AGENTS.md` y el paquete de construcción se generarán en el paso previsto. No publicar sin comprobaciones de calidad y seguridad. **No escribir claves, tokens, contraseñas ni secretos** en este archivo ni en `docs/`.

## 7. Cómo responder

- Responder **en español**, con estructura clara y lenguaje de Product Management.
- El proceso se **proyectará en directo** durante un workshop de tres horas: priorizar respuestas concisas, pasos accionables, tablas breves y entregables fáciles de explicar en pantalla.
- Indicar siempre **qué skill se está usando**, **qué documentos de entrada ha leído**, **qué propone generar o modificar**, **qué evidencia lo respalda** y **qué requiere aprobación del responsable de producto**.
- Diferenciar hechos, hipótesis, propuestas, decisiones aprobadas y resultados realmente verificados. No anticipar funcionalidades ni ejecutar cambios externos sin el consentimiento específico exigido por las skills.
