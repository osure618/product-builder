# CADUCA · Índice y alcance de las fuentes

Este directorio contiene el material de investigación del caso: documentos públicos, entrevistas, encuesta, observaciones, diario de alimentos y artefactos de hábitos actuales. Todos los archivos mantienen IDs para citar hallazgos y contrastar fuentes.

## Contenido

- `00_contexto/`: desk research, brief de encargo e índice de fuentes.
- `01_investigacion/01_entrevistas/`: cinco entrevistas semiestructuradas.
- `01_investigacion/02_encuesta/`: cuestionario, 24 registros y ficha técnica.
- `01_investigacion/03_observaciones/`: tres observaciones de hogares.
- `01_investigacion/04_diario/`: 30 registros de alimentos y metodología.
- `01_investigacion/05_artefactos/`: sistemas de organización y fragmentos de coordinación.

## Cómo trabajar con las fuentes

- Usar `00_contexto/03_indice_fuentes.csv` para citar IDs y rutas exactas.
- Distinguir testimonios, observaciones, datos declarados e inferencias. No presentar una muestra de 24 registros como representativa de la población.
- Analizar contradicciones y límites del corpus, sin inventar frecuencias, causalidad o impacto.
- El encargo exige construir una **app web sencilla**; el discovery decide problema, usuarios, alcance, funcionalidades y criterios de aceptación.
- Las skills de Product Builder crean sus propios entregables en `docs/`; ninguna decisión de MVP está aprobada en el material inicial.
- No sugerir consumo de alimentos tras su fecha de caducidad; diferenciar caducidad y consumo preferente.

**Nota de procedencia (única declaración general):** las fuentes de participantes y hogares son reconstrucciones preparadas para esta formación; no proceden de entrevistas, encuestas u observaciones reales. Son válidas para analizar el caso, pero no deben presentarse como validación de campo ni atribuirse a personas reales. Los documentos `PUB` sí proceden de fuentes públicas identificadas.
