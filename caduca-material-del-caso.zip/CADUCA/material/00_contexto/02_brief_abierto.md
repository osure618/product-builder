# Brief de partida — CADUCA

## Encargo del producto

Una asociación vecinal quiere ayudar a hogares urbanos a **aprovechar mejor los alimentos que ya tienen en casa**, reduciendo el desperdicio evitable. El encargo al equipo de producto incluye desarrollar una **aplicación web sencilla, pensada para móvil**, que pueda probarse con usuarios.

**Decisión de partida:** se construirá una aplicación digital. Permanecen abiertos el problema prioritario, los segmentos, el alcance, las funcionalidades y el diseño. Los hábitos y soluciones manuales existentes sirven como evidencia e inspiración para la app, no como alternativa a construirla.

## Situación inicial

Una asociación vecinal ha escuchado que algunas personas encuentran productos olvidados en la nevera, tiran comida que compraron con buena intención o descubren demasiado tarde que no van a poder consumirla. Ha pedido al equipo que investigue antes de elegir solución.

## Objetivo del trabajo

1. Identificar actores, trabajos a realizar, fricciones y consecuencias.
2. Distinguir hechos documentados, opiniones, contradicciones y suposiciones.
3. Priorizar un problema expresado sin prescribir funcionalidad.
4. Contrastar soluciones digitales y patrones de interfaz, tomando los hábitos actuales como contexto.
5. Definir, diseñar e implementar un MVP web mínimo con criterios de aceptación y validación.

## Restricciones del encargo (no son necesidades declaradas por usuarios)

- 1 tipo de usuario; sin panel administrador ni relaciones entre perfiles.
- Máximo 4 features implementables y, preferentemente, 1 tabla de datos persistente.
- 1 pantalla principal y un formulario como máximo.
- Sin integraciones, escaneo, OCR, IA de recetas, pagos ni notificaciones del sistema operativo.
- No recoger información sanitaria ni datos personales identificativos.
- Seguridad alimentaria no negociable: nada de sugerir consumo tras la fecha de caducidad.

## Preguntas deliberadamente no resueltas

- ¿Qué significa para el usuario "aprovechar mejor"?
- ¿Qué alimentos provocan más fricción y cuáles son oportunidades abordables mediante una app sencilla?
- ¿El usuario quiere recordar, decidir qué cocinar, hacer la compra mejor o coordinarse con su hogar?
- ¿Cómo reducir esfuerzo de entrada y mantenimiento de datos?
- ¿Qué métrica indicaría valor, y cuál sería su línea base real?

No proponer funcionalidades aún: primero analizar evidencia.
