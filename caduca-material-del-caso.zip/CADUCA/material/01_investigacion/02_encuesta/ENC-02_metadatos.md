# ENC-01 · Ficha técnica de la encuesta

- Registros disponibles: **n=24**. Identificadores P01–P24.
- Muestreo: intencional, no probabilístico, perfiles de 1 a 4 personas por hogar.
- No se dispone de ficha de reclutamiento ni registro de consentimiento en el corpus; no inferir representatividad a partir de estos materiales.
- Fechas representadas: primera quincena de noviembre de 2026.
- La pregunta «descartes en dos semanas» recoge percepción/recuerdo, **no medición objetiva**.
- Categorías y frecuencias en castellano, no están numéricamente codificadas para evitar falsa precisión.
- No existen variables socioeconómicas ni antecedentes de salud: no se necesitan para el caso.
- Cruces útiles: frecuencia de desperdicio declarado vs disposición a registrar; problema principal vs método actual; preferencia de notificaciones no medida directamente.
- **Alerta metodológica:** las entrevistas INT-01 a INT-05 seleccionan perfiles concretos; sus citas no deben extrapolarse a las 24 respuestas.
