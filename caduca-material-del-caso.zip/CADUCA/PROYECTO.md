# CADUCA · Contexto inicial del proyecto

> Documento de partida redactado por el Product Manager antes de iniciar el trabajo con Claude. Vive en la raíz del proyecto; las skills generan y mantienen `docs/`.
> **Última actualización:** 2026-11-15.

## 1. Qué es

CADUCA es una iniciativa de una asociación vecinal orientada a ayudar a hogares urbanos a aprovechar mejor los alimentos que ya tienen en casa y reducir descartes evitables. Las personas describen olvidos de alimentos, productos que se deterioran antes de consumirse y dificultades para decidir qué aprovechar primero. El encargo es investigar las causas, las situaciones y las necesidades prioritarias para diseñar una respuesta útil.

Esta descripción no presupone que el problema dominante sean las fechas de caducidad ni adelanta ninguna funcionalidad concreta.

## 2. Quién lo dirige y quién valida

- **Product Manager y responsable de decisiones:** Oscar Subirats. Aprueba el problem framing, el MVP, el alcance de cada feature, el diseño, las migraciones y los pasos con efectos externos.
- **Validación funcional y de negocio:** los perfiles de usuarios y la asociación aportan contexto a través de `material/`. La decisión del ejercicio corresponde al PM; los hallazgos no equivalen por sí solos a validación de mercado.
- **Autorizaciones:** ninguna propuesta de una skill queda APROBADA sin confirmación expresa. Cada operación externa requiere el «adelante» específico previsto por Product Setup, Product Builder o Product Quality.

## 3. Material de partida y límites

| Material | Ubicación | Alcance / límite |
| --- | --- | --- |
| Informes públicos, brief e índice de fuentes | `material/00_contexto/` | Aportan contexto sectorial; no prueban las causas en los hogares del caso. |
| Cinco entrevistas (Ana, Bruno, Carla, Diego y Elena) | `material/01_investigacion/01_entrevistas/` | Cinco perspectivas cualitativas, no representativas. |
| Cuestionario y 24 registros de encuesta | `material/01_investigacion/02_encuesta/` | Muestra de 24 registros; no inferir porcentajes poblacionales. |
| Tres observaciones domésticas | `material/01_investigacion/03_observaciones/` | Tres contextos concretos; no generalizar. |
| Diario de 30 alimentos | `material/01_investigacion/04_diario/` | Periodo limitado, sin baseline ni pesos; no demuestra impacto o ahorro. |
| Artefactos de hábitos y mensajes | `material/01_investigacion/05_artefactos/` | Fragmentos cualitativos que deben leerse en contexto. |

Consultar `material/00_contexto/03_indice_fuentes.csv` y citar identificadores, preguntas o filas. Comprobar contradicciones, lagunas y sesgos, sin completarlos con suposiciones.

**Procedencia:** la asociación y las fuentes de participantes y hogares forman parte de un escenario reconstruido para esta formación, no trabajo de campo real; debe tratarse como documentación de caso, no como investigación validada externamente. Los informes públicos tienen fuentes propias.

## 4. Restricciones

- **Seguridad alimentaria:** diferenciar fecha de caducidad y consumo preferente; no recomendar el consumo de productos pasada su fecha de caducidad ni asegurar que algo es inocuo por una fecha introducida por el usuario.
- **Privacidad:** no almacenar datos sanitarios, direcciones, identificadores personales innecesarios, menores ni datos sensibles. Usar registros de prueba para la demostración.
- **Simplicidad técnica y funcional:** un solo perfil de usuario, un máximo de cuatro features, interfaz web muy sencilla, idealmente una tabla de datos y una pantalla principal más un formulario.
- **Fuera del primer alcance:** pagos, OCR, escaneo, recetas generadas por IA, notificaciones push, coordinación multiusuario y otras integraciones no indispensables.
- **Seguridad técnica:** no publicar secretos; exigir control de acceso y RLS adecuados antes de exponer bases de datos.

## 5. Decisiones ya tomadas

- **Se desarrollará una aplicación web pensada para móvil (mobile-first)** mediante vibe-coding. Esta es una decisión del encargo, no una hipótesis del discovery.
- El resultado se demostrará durante la Upskill Week del **18 de noviembre de 2026**, utilizando el caso para enseñar el método de Product Management asistido por IA.
- El discovery debe decidir **qué problema resolverá la aplicación, para quién, con qué funcionalidades y con qué métrica**. No hay MVP, funcionalidades ni modelo de datos aprobados al inicio.
- Product Builder gobierna la definición, Product Setup la configuración de entorno (F00) y Product Quality las pruebas y la promoción a producción, conforme a sus `SKILL.md` vigentes.
- El proyecto comienza en local: `PROYECTO.md` y `material/` son entradas; `docs/` lo generan las skills. `material/` no se sube a GitHub.
- El benchmark se orienta a productos, flujos y patrones de solución digital; se estudian los hábitos manuales existentes para inspirar el diseño y reducir fricción, no para reabrir la decisión de desarrollar una app.

## 6. Herramientas

| Función | Herramienta | Configuración y estado |
| --- | --- | --- |
| Coordinación y definición | Claude + Product Builder | Carpeta local compartida; aprobación documental del PM. |
| Configuración del entorno | Product Setup | F00; verificar conexiones antes de hacer cambios. |
| Repositorio y ramas | GitHub | Repositorio generado al conectar Lovable; `develop` para construcción y `main` para producción mediante PR. Existencia y permisos pendientes de verificar. |
| Construcción | Lovable | En `develop`, conectado al proyecto Supabase de desarrollo; workspace pendiente de verificar. |
| Base de datos | Supabase propio | Proyectos separados de desarrollo y producción; migraciones aprobadas y RLS; no usar Lovable Cloud como sustituto. |
| Diseño | Claude Design | Sistema y pantallas según entregables aprobados de Product Builder. |
| Pruebas y seguridad | Product Quality + Playwright | Tests sobre vista previa, revisión de seguridad y puerta VERDE/ROJO. |
| Despliegue | Vercel | Preview protegida de `develop` y producción desde `main`; subdominio concreto pendiente de fijar. |
| Analítica | Por decidir | No incorporar PostHog por defecto. |

Los accesos, claves, contraseñas, tokens y secretos van exclusivamente en los sistemas autorizados, nunca en este archivo ni en el repositorio. Las configuraciones se registran en `docs/tech/entorno.md` cuando se verifiquen.

## 7. Cómo responder

- **Idioma:** castellano.
- **Contexto:** el proceso se proyectará en directo ante una audiencia; utilizar explicaciones claras, breves y fáciles de seguir en pantalla.
- **Método:** indicar qué skill se ejecuta, qué entradas consulta, qué artefactos genera, su estado y qué decisiones necesitan aprobación.
- **Evidencia:** citar las fuentes de `material/`, distinguir hechos y testimonios de inferencias, y registrar contradicciones o incertidumbre sin inventar conclusiones.
- **Gobernanza:** presentar opciones y solicitar el «adelante» para cada cambio externo; no fingir una integración comprobada ni un test superado.
- **Ritmo:** priorizar el avance paso a paso del método y no ampliar el alcance de la aplicación por iniciativa propia.
